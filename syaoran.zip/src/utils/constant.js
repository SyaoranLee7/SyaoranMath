// 常量
const constant = {
    colorBoxDark: [
        "#990066", "#FFFF00", "#003399", "#CC0033", "#333333", "#CCCC00", "#666666", "#FF6600"
    ]
};

export default constant;
