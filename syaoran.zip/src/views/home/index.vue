<template>
    <div class="home">

    </div>
</template>

<script>
export default {
    name: "Home",

    data () {
        return {
        };
    },

    created () {
    }
};
</script>

<style lang="scss" scoped>
.home {
    width: 100%;
    height: 100%;
    background: #000000 url("../../assets/images/home_bg.jpg") 100%;
}
</style>
